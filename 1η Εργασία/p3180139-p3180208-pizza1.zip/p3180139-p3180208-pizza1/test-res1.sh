gcc p3180139-p3180208-pizza1.c -pthread
./a.out 100 1000
read -p "Press enter to continue"
